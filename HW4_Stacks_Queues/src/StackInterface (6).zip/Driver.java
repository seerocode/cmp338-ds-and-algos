
public class Driver implements DriverInterface {

	@Override
	public QueueInterface<String> createQueue(QueueType queueType, QueueTestType queueTestType) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public StackInterface<String> createStack(StackType stackType, StackTestType stackTestType) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public RunTime runQueueTestCase(QueueType queueType, QueueTestType queueTestType, int numberOfTimes) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public RunTime runStackTestCase(StackType stackType, StackTestType stackTestType, int numberOfTimes) {
		// TODO Auto-generated method stub
		return null;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
