
public class RunTime implements RunTimeInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public TimeUnits getTimeUnits() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setTimeUnits(TimeUnits timeUnits) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public MemoryUnits getMemoryUnits() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setMemoryUnits(MemoryUnits memoryUnits) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public double getLastRunTime() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double getLastMemoryUsage() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double[] getRunTimes() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double[] getMemoryUsages() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void resetRunTimes() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addRuntime(long runTime) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public double getAverageRunTime() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double getAverageMemoryUsage() {
		// TODO Auto-generated method stub
		return 0;
	}

}
