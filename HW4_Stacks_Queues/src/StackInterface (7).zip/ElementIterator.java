import java.util.Iterator;

public class ElementIterator<E> implements Iterator<E> {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean hasNext() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public E next() {
		// TODO Auto-generated method stub
		return null;
	}

}
