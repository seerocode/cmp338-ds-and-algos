import java.util.Vector;

public class Driver implements DriverInterface {

	@Override
	public QueueInterface<String> createQueue(QueueType queueType, QueueTestType queueTestType) {
		// TODO Auto-generated method stub
		switch(queueType) {
		case ArrayBasedQueue:
			switch (queueTestType) {
			case Enqueue:
				ArrayBasedQueue<String> arrayEnqueue = new ArrayBasedQueue<String>();
				
				for (int i = 1; i <= 10000; i++) {
					arrayEnqueue.enqueue("String " + i);
				}
				
			case Dequeue:
				ArrayBasedQueue<String> arrayDequeue = new ArrayBasedQueue<String>();
				
				for (int i = 1; i <= 10000; i++) {
					arrayDequeue.enqueue("String " + i);
				}
				
				for (int i = 1; i <= 10000; i++) {
					arrayDequeue.dequeue();
				}
				
			case Iterate:
			}
		case LinkedQueue:
			switch (queueTestType) {
			case Enqueue:
			case Dequeue:
			case Iterate:
			}
		}
		
		return null;
	}

	@Override
	public StackInterface<String> createStack(StackType stackType, StackTestType stackTestType) {
		
		switch(stackType) {
		case ArrayBasedStack:
			switch (stackTestType) {
			case Push:
			case Pop:
			case Iterate:
			}
		case LinkedStack:
			switch (stackTestType) {
			case Push:
			case Pop:
			case Iterate:
			}
		}
		
		return null;
	}

	@Override
	public RunTime runQueueTestCase(QueueType queueType, QueueTestType queueTestType, int numberOfTimes) {
		switch(queueType) {
		case ArrayBasedQueue:
			
		case LinkedQueue:
		}
		
		return null;
	}

	@Override
	public RunTime runStackTestCase(StackType stackType, StackTestType stackTestType, int numberOfTimes) {
		// TODO Auto-generated method stub
		return null;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
