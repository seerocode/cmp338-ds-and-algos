
public class RunTime implements RunTimeInterface {
	
	private double[] runTimeArray = new double[10];
	private double[] memoryArray = new double[10];
	private int runTimeCounter = 0;
	private int memoryCounter = 0;

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	}

	@Override
	public TimeUnits getTimeUnits() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setTimeUnits(TimeUnits timeUnits) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public MemoryUnits getMemoryUnits() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setMemoryUnits(MemoryUnits memoryUnits) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public double getLastRunTime() {
		double lastIndex = 0;
		
		// start index at last number, while index greater than zero, go into loop
		for (int runTimeIndex = runTimeArray.length - 1; runTimeIndex >= 0; runTimeIndex--) {
			// set lastIndex if not zero
			if (runTimeArray[runTimeIndex] != 0) {
				lastIndex = runTimeArray[runTimeIndex];
				break;
			} 
		}
		return lastIndex;
	}

	@Override
	public double getLastMemoryUsage() {
		double lastIndex = 0;
		
		// start index at last number, while index greater than zero, go into loop
		for (int memoryIndex = memoryArray.length - 1; memoryIndex >= 0; memoryIndex--) {
			// set lastIndex if not zero
			if (memoryArray[memoryIndex] != 0) {
				lastIndex = memoryArray[memoryIndex];
				break;
			} 
		}
		return lastIndex;
	}

	@Override
	public double[] getRunTimes() {
		return this.runTimeArray;
	}

	@Override
	public double[] getMemoryUsages() {
		return this.memoryArray;
	}

	@Override
	public void resetRunTimes() {
		// for each element in the array, set to zero
				for (int runTimeIndex = 0; runTimeIndex < this.runTimeArray.length; runTimeIndex++) {
					this.runTimeArray[runTimeIndex] = 0;
				}
				// reset the runTimeCounter
				this.runTimeCounter = 0;
		
	}

	@Override
	public void addRuntime(long runTime) {
		// have a counter for the num of elements have starting at zero
				// every time you add a runtime, if the counter is less than 10, place runtime
				// at counter and increment
				// when the counter reaches 10, you have your full array
				
				// start counter at zero
				
				// if counter is less than 10, add a runtime at that index number for the runTimeArray
				if (this.runTimeCounter < 10) {
					runTimeArray[this.runTimeCounter] = runTime;
					// increase the counter by one for the next slot in the array
					this.runTimeCounter++;
				}
				// otherwise, if the counter reaches the last element, shift all items to left
				else if (this.runTimeCounter >= 10) {
					for (int runTimeIndex = 0; runTimeIndex < runTimeArray.length - 1; runTimeIndex++) {
						runTimeArray[runTimeIndex] = runTimeArray[runTimeIndex + 1];
					}
					// add runtime to last slot in the array
						runTimeArray[runTimeArray.length - 1] = runTime;
				}
		
	}

	@Override
	public double getAverageRunTime() {
		double countHolder = 0;
		double meanOfRunTimes;
		
		// if the counter is <= 10, go through array and add up the runtimes
		if (this.runTimeCounter <= 10) {
			for (int runTimeIndex = 0; runTimeIndex < this.runTimeCounter; runTimeIndex++) {
				countHolder = countHolder + runTimeArray[runTimeIndex];
			}
		}
		
		// if the counts are equal to zero, set the mean to zero
		if (countHolder == 0) {
			meanOfRunTimes = 0;
		}
		// otherwise, set the mean to the mean of the counts
		else {
			meanOfRunTimes = countHolder / this.runTimeCounter;
		}
		
		return meanOfRunTimes;
	}

	@Override
	public double getAverageMemoryUsage() {
		double countHolder = 0;
		double meanOfMemoryUsage;
		
		// if the counter is <= 10, go through array and add up the runtimes
		if (this.memoryCounter <= 10) {
			for (int memoryIndex = 0; memoryIndex < this.runTimeCounter; memoryIndex++) {
				countHolder = countHolder + memoryArray[memoryIndex];
			}
		}
		
		// if the counts are equal to zero, set the mean to zero
		if (countHolder == 0) {
			meanOfMemoryUsage = 0;
		}
		// otherwise, set the mean to the mean of the counts
		else {
			meanOfMemoryUsage = countHolder / this.memoryCounter;
		}
		
		return meanOfMemoryUsage;
	}

}
