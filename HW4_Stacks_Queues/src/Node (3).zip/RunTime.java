
public class RunTime implements RunTimeInterface {
	
	private double[] runTimeArray = new double[10];
	private double[] memoryArray = new double[10];
	private int runTimeCounter = 0;
//	private int memoryCounter = 0;
	
	private TimeUnits timeUnit;
	private MemoryUnits memUnit;
	private Double time;
	private Double mem;

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	}

	@Override
	public TimeUnits getTimeUnits() {
		return this.timeUnit;
	}

	@Override
	public void setTimeUnits(TimeUnits timeUnits) {
//		switch (timeUnits) {
//		case NanoSeconds:
//			this.time = 1D;
//			break;
//		case MicroSeconds:
//			this.time = 1000D;
//			break;
//		case MilliSeconds:
//			this.time = 1000000D;
//			break;
//		case Seconds:
//			this.time = 1000000000D;
//			break;
//		}
		
		this.timeUnit = timeUnits;
		
	}

	@Override
	public MemoryUnits getMemoryUnits() {
		return memUnit;
	}

	@Override
	public void setMemoryUnits(MemoryUnits memoryUnits) {
//		switch(memoryUnits) {
//		case Bytes:
//			this.mem = 1D;
//			break;
//		case KiloBytes:
//			this.mem = 1024D;
//			break;
//		case MegaBytes:
//			this.mem = 1048576D;
//			break;
//			
//		}
		
		this.memUnit = memoryUnits;
		
	}

	@Override
	public double getLastRunTime() {
		double lastIndex = 0;
		
		// start index at last number, while index greater than zero, go into loop
//		for (int runTimeIndex = runTimeArray.length - 1; runTimeIndex >= 0; runTimeIndex--) {
//			// set lastIndex if not zero
//			if (runTimeArray[runTimeIndex] != 0) {
//				lastIndex = runTimeArray[runTimeIndex];
//				break;
//			} 
//		}
		
		if(timeUnit == TimeUnits.Seconds){
			return ((runTimeArray[runTimeCounter -1]) / mem); 
		}
		else if(timeUnit == TimeUnits.MilliSeconds){
			return ((runTimeArray[runTimeCounter - 1])/ mem);
		}
		else if(timeUnit == TimeUnits.MicroSeconds){
			return ((runTimeArray[runTimeCounter - 1]) / mem);
		}
		else{
			return runTimeArray[runTimeCounter - 1];
		}
		
	}

	@Override
	public double getLastMemoryUsage() {
		double lastIndex = 0;
		
		// start index at last number, while index greater than zero, go into loop
//		for (int memoryIndex = memoryArray.length - 1; memoryIndex >= 0; memoryIndex--) {
//			// set lastIndex if not zero
//			if (memoryArray[memoryIndex] != 0) {
//				lastIndex = memoryArray[memoryIndex];
//				break;
//			} 
//		}
		
		if(this.memUnit == MemoryUnits.KiloBytes){
			return (memoryArray[runTimeCounter - 1])/ (1024);
		}
		else if(this.memUnit == MemoryUnits.MegaBytes){
			return (memoryArray[runTimeCounter - 1]) / (1048576);
		}
		else{
			return memoryArray[runTimeCounter - 1];
		}
		
	}

	@Override
	public double[] getRunTimes() {
//		return this.runTimeArray;
		
		//if time units equals seconds
				if(this.timeUnit == TimeUnits.Seconds){
					//make a temporary array
					double[] temporaryArray = new double[10];
					//loop through
					for(int i = 0; i < 10; i++){
						temporaryArray[i] = ((runTimeArray[i]) / (1000000000));//1000 * 1000 * 1000
					}

					return temporaryArray;
				}

				//if time units equals milliseconds
				else if(this.timeUnit == TimeUnits.MilliSeconds){
					//make a temporary array
					double[] temporaryArray = new double[10];
					//loop through
					for(int i = 0; i < 10; i++){
						temporaryArray[i] = ((runTimeArray[i]) / (1000000)); // 1000 * 1000
					}

					return temporaryArray;
				}

				//if time units equals microseconds
				else if(this.timeUnit == TimeUnits.MicroSeconds){
					//make a temporary array
					double[] temporaryArray = new double[10];
					//loop through
					for(int i = 0; i < 10; i++){
						temporaryArray[i] = ((runTimeArray[i]) / (1000));
					}

					return temporaryArray;
				}
				//else:
				return runTimeArray;
	}

	@Override
	public double[] getMemoryUsages() {
//		return this.memoryArray;
		
		if(this.memUnit == MemoryUnits.KiloBytes){
			//create a temporary array
			double [] temporaryArray = new double[10];
			for(int i = 0; i < 10; i++){
				temporaryArray[i] = ((memoryArray[i]) / (1024));
			}
			return temporaryArray;
		}

		//if memory units equal megabytes
		else if(this.memUnit == MemoryUnits.MegaBytes){
			//create a temporary array
			double [] temporaryArray = new double[10];
			for(int i = 0; i < 10; i++){
				temporaryArray[i] = ((memoryArray[i]) / (1048576));
			}
			return temporaryArray;
		}
		//else:
		return memoryArray;
	}

	@Override
	public void resetRunTimes() {
		// for each element in the array, set to zero
//				for (int runTimeIndex = 0; runTimeIndex < this.runTimeArray.length; runTimeIndex++) {
//					this.runTimeArray[runTimeIndex] = 0;
//				}
		
		runTimeArray = new double[10];
		memoryArray = new double[10];
		
				// reset the runTimeCounter
				this.runTimeCounter = 0;
		
	}

	@Override
	public void addRuntime(long runTime) {
		// have a counter for the num of elements have starting at zero
				// every time you add a runtime, if the counter is less than 10, place runtime
				// at counter and increment
				// when the counter reaches 10, you have your full array
				
				// start counter at zero
				
				// if counter is less than 10, add a runtime at that index number for the runTimeArray
//				if (this.runTimeCounter < 10) {
//					runTimeArray[this.runTimeCounter] = runTime;
//					// increase the counter by one for the next slot in the array
//					this.runTimeCounter++;
//				}
//				// otherwise, if the counter reaches the last element, shift all items to left
//				else if (this.runTimeCounter >= 10) {
//					for (int runTimeIndex = 0; runTimeIndex < runTimeArray.length - 1; runTimeIndex++) {
//						runTimeArray[runTimeIndex] = runTimeArray[runTimeIndex + 1];
//					}
//					// add runtime to last slot in the array
//						runTimeArray[runTimeArray.length - 1] = runTime;
//				}
		
		if(runTimeCounter < runTimeArray.length){
			//assign runTime to the runtime array
			runTimeArray[runTimeCounter] = runTime;
			//add to memory usage array
			memoryArray[runTimeCounter] = ((Runtime.getRuntime().totalMemory()) - (Runtime.getRuntime().freeMemory()));
			//increment index
			runTimeCounter++;

		}

		else{
			//loop through
			for(int i = 0; i < (runTimeArray.length - 1); i++){
				runTimeArray[i] = runTimeArray[i + 1];
				memoryArray[i] = memoryArray[i + 1];

			}
			//add to memory
			memoryArray[memoryArray.length - 1]/*[9]*/ = ((Runtime.getRuntime().totalMemory()) - (Runtime.getRuntime().freeMemory()));
			runTimeArray[runTimeArray.length - 1]/*[9]*/ = runTime;

		}
		
	}

	@Override
	public double getAverageRunTime() {
//		double countHolder = 0;
//		double meanOfRunTimes;
//		
//		// if the counter is <= 10, go through array and add up the runtimes
//		if (this.runTimeCounter <= 10) {
//			for (int runTimeIndex = 0; runTimeIndex < this.runTimeCounter; runTimeIndex++) {
//				countHolder = countHolder + runTimeArray[runTimeIndex];
//			}
//		}
//		
//		// if the counts are equal to zero, set the mean to zero
//		if (countHolder == 0) {
//			meanOfRunTimes = 0;
//		}
//		// otherwise, set the mean to the mean of the counts
//		else {
//			meanOfRunTimes = countHolder / this.runTimeCounter;
//		}
//		
//		return meanOfRunTimes;
		
		double sum = 0.0;
		//loop through to get the sum of all of the elements
		for(int i = 0; i < runTimeCounter; i++){
			sum = sum + runTimeArray[i];
		}
		//get the average
		double averageRunTime = (double) sum / runTimeCounter;

		//if time units equal seconds
		if(this.timeUnit == TimeUnits.Seconds){

			return (averageRunTime / (1000000000)); //1000 * 1000 * 1000
		}

		//if time units equal milliseconds
		else if(this.timeUnit == TimeUnits.MilliSeconds){

			return (averageRunTime / (1000000)); //1000 * 1000
		}

		//if time units equal microseconds
		else if(this.timeUnit == TimeUnits.MicroSeconds){

			return (averageRunTime / (1000));
		}
		
		else{
			return averageRunTime;
		}
	}

	@Override
	public double getAverageMemoryUsage() {
		double sum = 0;
		double meanOfMemoryUsage;
		
//		// if the counter is <= 10, go through array and add up the runtimes
//		if (this.runTimeCounter <= 10) {
//			for (int memoryIndex = 0; memoryIndex < this.runTimeCounter; memoryIndex++) {
//				countHolder = countHolder + memoryArray[memoryIndex];
//			}
//		}
//		
//		// if the counts are equal to zero, set the mean to zero
//		if (countHolder == 0) {
//			meanOfMemoryUsage = 0;
//		}
//		// otherwise, set the mean to the mean of the counts
//		else {
//			meanOfMemoryUsage = countHolder / this.runTimeCounter;
//		}
//		
//		//if memory units equals kilobytes
//				if(this.memUnit == MemoryUnits.KiloBytes){
//					
//					return (meanOfMemoryUsage /(1024));
//				}
//				
//				//if memory units equals megabytes
//				else if(this.memUnit == MemoryUnits.MegaBytes){
//					
//					return (meanOfMemoryUsage / (1048576)); //divided by 1024 * 1024
//				}
//		
//		return meanOfMemoryUsage;
		
		//loop through to get the total
		for(int i = 0; i < runTimeCounter; i++){
			sum = sum + memoryArray[i];
		}
		
		//calculate the average
		double averageMemoryUsage = sum / runTimeCounter;
		
		//if memory units equals kilobytes
		if(this.memUnit == MemoryUnits.KiloBytes){
			
			return (averageMemoryUsage /(1024));
		}
		
		//if memory units equals megabytes
		else if(this.memUnit == MemoryUnits.MegaBytes){
			
			return (averageMemoryUsage / (1048576)); //divided by 1024 * 1024
		}
	
		return averageMemoryUsage;
	}

}
