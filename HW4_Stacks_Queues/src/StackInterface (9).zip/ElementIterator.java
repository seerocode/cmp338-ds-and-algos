import java.util.Iterator;
import java.util.NoSuchElementException;

public class ElementIterator<E> implements Iterator<E> {
	
	private Node<E> current;
    private Node<E> last;
    private int numElements;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public ElementIterator(Node<E> stackQueue, int size) {
		current = stackQueue;
		numElements = size;
	}

	@Override
	public boolean hasNext() {
		return current != null;
	}

	@Override
	public E next() {
		if (! this.hasNext())
	         throw new NoSuchElementException();

	      @SuppressWarnings("unchecked")
		E result = (E) this.current.getData();
	      this.current = this.current.getNext();
	      return result;
	}

}
