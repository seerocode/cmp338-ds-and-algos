import java.util.Iterator;
import java.util.NoSuchElementException;

public class LinkedQueue<E> implements QueueInterface<E> {
	
	private Node<E> front = null; // reference to node at front
	private Node<E> back = null; // reference to node at back
	
	private int size = 0; // size of the stack

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	}

	@Override
	public Iterator<E> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isEmpty() {
		return size == 0; // return T or F if size is 0
	}

	@Override
	public int size() {
		return this.size;
	}

	@Override
	public void enqueue(E e) throws IllegalStateException, NullPointerException {
		Node<E> newNode = new Node(e);
		 if (this.front == null) {
		 this.front = newNode;
		 } else {
		 this.back.setNext(newNode);
		 newNode.setPrevious(this.back);
		 this.back = newNode;
		 this.size++;
		 }
		
	}

	@Override
	public E peek() {
		if (isEmpty()) throw new NoSuchElementException("Queue empty");
        return front.getData();
	}

	@Override
	public E dequeue() {
		if (isEmpty()) throw new NoSuchElementException("Queue empty");
		E obj = front.getData();
		this.front = front.getNext(); // set front to next node
		this.size--; //decrease size by one
		
		return obj;
	}

	@Override
	public E dequeue(int index) throws NoSuchElementException {
		if (isEmpty()) throw new NoSuchElementException("Queue empty");
		E obj = front.getData();
		this.front = front.getNext(); // set front to next node
		this.size--; //decrease size by one
		
		return obj;
	}

	@Override
	public void removeAll() {
		this.front = null;
		this.back = null;
		this.size = 0;
		
	}

}
