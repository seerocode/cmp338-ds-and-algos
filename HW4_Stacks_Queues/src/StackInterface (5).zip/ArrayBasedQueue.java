import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Vector;

public class ArrayBasedQueue<E> implements QueueInterface<E> {
	
	private Vector<E> queueVector = new Vector<E>();
	private final int INVALID_STACK_POINTER = -1;
	private int stackPointer = INVALID_STACK_POINTER;

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	}

	@Override
	public Iterator<E> iterator() {
		return queueVector.listIterator();
	}

	@Override
	public boolean isEmpty() {
		return queueVector.isEmpty();
	}

	@Override
	public int size() {
		return queueVector.size();
	}

	@Override
	public void enqueue(E e) throws IllegalStateException, NullPointerException {
		queueVector.add(++stackPointer, e);
		
	}

	@Override
	public E peek() {
		if (queueVector.isEmpty()) {
			return null;
		}
		else {
			return queueVector.get(stackPointer);
		}
	}

	@Override
	public E dequeue() {
		E obj = null;
		 if (stackPointer != INVALID_STACK_POINTER) {
		 obj = queueVector.firstElement();
		 queueVector.removeElementAt(0);
		 }
		 return obj;
	}

	@Override
	public E dequeue(int index) throws NoSuchElementException {
		E obj = null;
		 if (stackPointer != INVALID_STACK_POINTER && !(index < 0) && !(index > queueVector.size())) {
		 obj = queueVector.elementAt(index);
		 queueVector.removeElementAt(index);
		 }
		 return obj;
	}

	@Override
	public void removeAll() {
		queueVector.clear();
		
	}

}
