import java.util.Arrays;
import java.util.Vector;

public class Driver implements DriverInterface {

	@Override
	public QueueInterface<String> createQueue(QueueType queueType, QueueTestType queueTestType) {
		// TODO Auto-generated method stub
		switch(queueType) {
		case ArrayBasedQueue:
			switch (queueTestType) {
			case Enqueue:
				ArrayBasedQueue<String> arrayEnqueue = new ArrayBasedQueue<String>();
				
//				for (int i = 1; i <= 10000; i++) {
//					arrayEnqueue.enqueue("String " + i);
//				}
				
				return arrayEnqueue;
			case Dequeue:
				ArrayBasedQueue<String> arrayDequeue = new ArrayBasedQueue<String>();
				
				for (int i = 1; i <= 10000; i++) {
					arrayDequeue.enqueue("String " + i);
				}
				
				for (int i = 1; i <= 10000; i++) {
					arrayDequeue.dequeue();
				}
				
				return arrayDequeue;
				
			case Iterate:
				
				ArrayBasedQueue<String> arrayIter = new ArrayBasedQueue<String>();
				
				for (int i = 1; i <= 10000; i++) {
					arrayIter.enqueue("String " + i);
				}
				
//				for (int i = 0; i < arrayIter.size(); i++) {
					while (arrayIter.iterator().hasNext()) {
						System.out.println(arrayIter.iterator().next());
					}
//				}
				
				return arrayIter;
			}
		case LinkedQueue:
			switch (queueTestType) {
			case Enqueue:
				LinkedQueue<String> linkEnqueue = new LinkedQueue<String>();
				
				for (int i = 1; i <= 10000; i++) {
					linkEnqueue.enqueue("String " + i);
				}
				
				return linkEnqueue;
				
			case Dequeue:
				LinkedQueue<String> linkDequeue = new LinkedQueue<String>();
				
				for (int i = 1; i <= 10000; i++) {
					linkDequeue.enqueue("String " + i);
				}
				
//				for (int i = 1; i <= 10000; i++) {
//					linkDequeue.dequeue();
//				}
				
				return linkDequeue;
				
			case Iterate:
				
				ArrayBasedQueue<String> linkIter = new ArrayBasedQueue<String>();
				
				for (int i = 1; i <= 10000; i++) {
					linkIter.enqueue("String " + i);
				}
				
//				for (int i = 0; i < linkIter.size(); i++) {
					while (linkIter.iterator().hasNext()) {
						System.out.println(linkIter.iterator().next());
//					}
				}
				
				return linkIter;
			}
		}
		
		return null;
	}

	@Override
	public StackInterface<String> createStack(StackType stackType, StackTestType stackTestType) {
		
		switch(stackType) {
		case ArrayBasedStack:
			switch (stackTestType) {
			case Push:
				ArrayBasedStack<String> arrayStackPush = new ArrayBasedStack<String>();
				
//				for (int i = 1; i <= 10000; i++) {
//					arrayStackPush.push("String " + i);
//				}
				
				return arrayStackPush;
			case Pop:
				ArrayBasedStack<String> arrayStackPop = new ArrayBasedStack<String>();
				
				for (int i = 1; i <= 10000; i++) {
					arrayStackPop.push("String " + i);
				}
				
//				for (int i = 1; i <= 10000; i++) {
//					arrayStackPop.pop();
//				}
				
				return arrayStackPop;
				
			case Iterate:
				ArrayBasedStack<String> arrayStackIter = new ArrayBasedStack<String>();
				
				for (int i = 1; i <= 10000; i++) {
					arrayStackIter.push("String " + i);
				}
				
//				for (int i = 0; i < arrayStackIter.size(); i++) {
					while (arrayStackIter.iterator().hasNext()) {
						System.out.println(arrayStackIter.iterator().next());
//					}
				}
				
				return arrayStackIter;
			}
		case LinkedStack:
			switch (stackTestType) {
			case Push:
				LinkedStack<String> linkStackPush = new LinkedStack<String>();
				
				for (int i = 1; i <= 10000; i++) {
					linkStackPush.push("String " + i);
				}
				
				return linkStackPush;
				
			case Pop:
				LinkedStack<String> linkStackPop = new LinkedStack<String>();
				
				for (int i = 1; i <= 10000; i++) {
					linkStackPop.push("String " + i);
				}
				
				for (int i = 1; i <= 10000; i++) {
					linkStackPop.pop();
				}
				
				return linkStackPop;
			case Iterate:
				LinkedStack<String> linkStackIter = new LinkedStack<String>();
				
				for (int i = 1; i <= 10000; i++) {
					linkStackIter.push("String " + i);
				}
				
				
					while (linkStackIter.iterator().hasNext()) {
						System.out.println(linkStackIter.iterator().next());
					}
//				}
				
				return linkStackIter;
			}
		}
		
		return null;
	}

	@Override
	public RunTime runQueueTestCase(QueueType queueType, QueueTestType queueTestType, int numberOfTimes) {
		
		
		switch(queueType) {
		case ArrayBasedQueue:
			
			RunTime runArrQueue = new RunTime();
			
			for (int i = 0; i < numberOfTimes; i++) {
				long startTime = System.nanoTime();
				
				this.createQueue(QueueType.ArrayBasedQueue, queueTestType);
				
				long endTime = System.nanoTime();
				long runTime = endTime - startTime;
				runArrQueue.addRuntime(runTime);
			}
			
			return runArrQueue;
			
		case LinkedQueue:
			
			RunTime run = new RunTime();
			
			for (int i = 0; i < numberOfTimes; i++) {
				long startTime = System.nanoTime();
				
				this.createQueue(QueueType.LinkedQueue, queueTestType);
				
				long endTime = System.nanoTime();
				long runTime = endTime - startTime;
				run.addRuntime(runTime);
			}
			
			return run;
		}
		
		return null;
	}

	@Override
	public RunTime runStackTestCase(StackType stackType, StackTestType stackTestType, int numberOfTimes) {
		
		
		switch(stackType) {
		case ArrayBasedStack:
			
			RunTime arrayStackRun = new RunTime();
			
			for (int i = 0; i < numberOfTimes; i++) {
				long startTime = System.nanoTime();
				
				this.createStack(StackType.ArrayBasedStack, stackTestType);
				
				long endTime = System.nanoTime();
				long runTime = endTime - startTime;
				arrayStackRun.addRuntime(runTime);
			}
			
			return arrayStackRun;
			
		case LinkedStack:
			RunTime linkedStackRun = new RunTime();
			
			for (int i = 0; i < numberOfTimes; i++) {
				long startTime = System.nanoTime();
				
				this.createStack(StackType.LinkedStack, stackTestType);
				
				long endTime = System.nanoTime();
				long runTime = endTime - startTime;
				linkedStackRun.addRuntime(runTime);
			}
			
			return linkedStackRun;
		}
		
		return null;
	}

	public static void main(String[] args) {
		
		ArrayBasedStack<String> linkStackIter = new ArrayBasedStack<String>();
		
		
		
		for (int i = 1; i <= 10; i++) {
			linkStackIter.push("String " + i);
//			System.out.print(i);
		}
		
//		System.out.println(linkStackIter.toString());
		
//		for (int i = 0; i < linkStackIter.size(); i++) {
			while (linkStackIter.iterator().hasNext()) {
				System.out.println(linkStackIter.iterator().next());
			}
//		}
//		
//		
//		
//			while (linkStackIter.iterator().hasNext()) {
//				System.out.println(linkStackIter.iterator().next());
//			}

	}

}
