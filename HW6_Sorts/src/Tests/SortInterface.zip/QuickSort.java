
public class QuickSort<T extends Comparable<? super T>> implements SortInterface<T> {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public void sort(T[] arrayToSort) {
		quickSort(arrayToSort, 0, arrayToSort.length - 1);
		// showArray(arrayToSort, 0, arrayToSort.length - 1);

	}
	
	/////////////////////////////////////////////////////////////////////

	private void quickSort(T[] array, int firstIndex, int lastIndex) {

		int pivotIndex;
		if (firstIndex < lastIndex) {
			pivotIndex = partition(array, firstIndex, lastIndex);
			quickSort(array, firstIndex, pivotIndex - 1);
			quickSort(array, pivotIndex + 1, lastIndex);
		}
	}

	private void choosePivot(T[] array, int first, int last) {
		// after this method returns, the chosen pivot is
		// always in the first location in the segment of the
		// array being worked on.

		// make mid element be the pivot
		int mid = (first + last) / 2;
		T temp = array[first];
		array[first] = array[mid];
		array[mid] = temp;

	}

	private int partition(T[] array, int first, int last) {

		T tempItem;
		int firstUnknown;

		choosePivot(array, first, last);
		T pivot = array[first];

		int lastS1 = first;

		for (firstUnknown = first + 1; firstUnknown <= last; firstUnknown++) {
			if (array[firstUnknown].compareTo(pivot) < 0) {
				lastS1++;
				tempItem = array[firstUnknown];
				array[firstUnknown] = array[lastS1];
				array[lastS1] = tempItem;
			}
		}

		// swap pivot with element at lastS1
		tempItem = array[first];
		array[first] = array[lastS1];
		array[lastS1] = tempItem;

		showArray(array, first, last);

		return lastS1;
	}

	private void showArray(T[] array, int first, int last) {
		System.out.print("Array = {");
		for (int i = first; i <= last; i++) {
			if (i != last) {
				System.out.print(array[i] + ", ");
			} else {
				System.out.print(array[i]);
			}
		}
		System.out.println("}");
	}
}
