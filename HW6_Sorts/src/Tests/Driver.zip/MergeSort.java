
public class MergeSort<T extends Comparable<? super T>> implements SortInterface<T> {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public void sort(T[] arrayToSort) {
		// TODO Auto-generated method stub
		
	}

}
