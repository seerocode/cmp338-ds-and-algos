
public class Driver implements DriverInterface {

	@Override
	public Integer[] createArray(ArrayType arrayType, int arraySize) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public RunTime[] runSorts(ArrayType arrayType, int arraySize, int numberOfTimes) {
		// TODO Auto-generated method stub
		return null;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
