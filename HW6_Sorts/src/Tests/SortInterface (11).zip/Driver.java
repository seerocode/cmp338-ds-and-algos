
public class Driver implements DriverInterface {

	static HeapSort heapSort;
	static QuickSort quickSort;
	static MergeSort mergeSort;
	
	SortType sortType;
	QuickSort.PivotType pivotType;

	@Override
	public Integer[] createArray(ArrayType arrayType, int arraySize) {
		switch (arrayType) {
		case Equal:
			Integer[] equalArray = new Integer[arraySize];
			for (int value = 0; value < equalArray.length; value++) {
				equalArray[value] = 1;
			}
			return equalArray;
		case Random:
			Integer[] randArray = new Integer[arraySize];
			for (int value = 0; value < randArray.length; value++) {
				randArray[value] = (int) (Math.random() * 100000);
			}
			return randArray;
		case Increasing:
			Integer[] incArray = new Integer[arraySize];
			for (int i = 0; i < incArray.length; i++) {
				incArray[i] = i + 1;
			}
			return incArray;
		case Decreasing:
			Integer[] decArray = new Integer[arraySize];
			int counter = arraySize;
			for (int i = 0; i < decArray.length; i++) {
				// assign and then decrement
				decArray[i] = counter--;
			}
			return decArray;
		case IncreasingAndRandom:
			// 90% increasing and 10% random
			// 90% of 1000 = 100 random numbers
			// 90% of 10,000 = 1000 random numbers
			Integer[] incAndRandArray = new Integer[arraySize];
			incAndRandArray[0] = 1;
			// - 1 so it doesnt go up to 901
			int arrayAt90Percent = (int) (incAndRandArray.length * .90);
			for (int i = 1; i < arrayAt90Percent; i++) {
				incAndRandArray[i] = i + 1;
			}
			for (int i = arrayAt90Percent; i < incAndRandArray.length; i++) {
				incAndRandArray[i] = (int) (Math.random() * 100000);
			}
			return incAndRandArray;
		}

		return null;
	}

	@Override
	public RunTime[] runSorts(ArrayType arrayType, int arraySize, int numberOfTimes) {
		RunTime[] runs = new RunTime[5];
		
		switch (arrayType) {
		case Decreasing:
			
			switch(sortType) {
			case MergeSort:
				// instantiate class
				MergeSort ms = new MergeSort();
				
				// create array
				Integer[] mergeArray = createArray(ArrayType.Decreasing, arraySize);
				
				// run the merge
				for (int i = 0; i < numberOfTimes; i++) {
					ms.sort(mergeArray);
				}
				// add runtime
				runs[0] = ms;
				
			case QuickSort:
				switch(pivotType) {
				case FirstElement:
					break;
				case RandomElement:
					break;
				case MidOfFirstMidLastElement:
					break;
				}
			case HeapSort:
				// instantiate class
				HeapSort hs = new HeapSort();
				
				// create array
				Integer[] heapArray = createArray(ArrayType.Decreasing, arraySize);
				
				// run the merge
				for (int i = 0; i < numberOfTimes; i++) {
					hs.sort(heapArray);
				}
				// add runtime
				runs[1] = hs;
			}

			

		case Equal:
			break;
		case Increasing:
			break;
		case IncreasingAndRandom:
			break;
		case Random:
			break;

		}

		// switch (arrayType) {
		// case Decreasing:
		// mergeSort = new MergeSort();
		// Integer[] mergeArray;
		// // test that it's random before sort
		// for (int counter = 0; counter < numberOfTimes; counter++) {
		// mergeArray = createArray(arrayType, arraySize);
		// mergeSort.sort(mergeArray);
		// // System.out.println(Arrays.toString(bubbleArray));
		// }
		// // test that its sorted after random
		// // System.out.println(Arrays.toString(bubbleArray));
		//
		// return mergeSort;
		// case Equal:
		// mergeSort = new MergeSort();
		// Integer[] mergeArray;
		// // test that it's random before sort
		// for (int counter = 0; counter < numberOfTimes; counter++) {
		// mergeArray = createArray(arrayType, arraySize);
		// mergeSort.sort(mergeArray);
		// // System.out.println(Arrays.toString(bubbleArray));
		// }
		// // test that its sorted after random
		// // System.out.println(Arrays.toString(bubbleArray));
		//
		// return mergeSort;
		// case SelectionSort:
		// // SelectionSort selection = new SelectionSort();
		// selection = new SelectionSort();
		// Integer[] selectionArray;
		// for (int counter = 0; counter < numberOfTimes; counter++) {
		// selectionArray = createArray(arrayType, arraySize);
		// selection.sort(selectionArray);
		// }
		//
		// return selection;
		// } // end switch
		// // } // end for loop

		return null;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
