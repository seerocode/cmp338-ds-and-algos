import java.util.Arrays;

public class Driver implements DriverInterface {
	
	private static int[] listOfNumbers = new int[10000000];
	private static int[] targets = {500, 10000, 100000, 1000000, 5000000, 7500000, 10000000};
	private static  BinarySearch newBinarySearch = new BinarySearch();
	private static LinearSearch newLinearSearch = new LinearSearch();
	private static RunTime rt = new RunTime();

	
	@Override
	public int[] getListOfNumbers() {
		
		int numCountUp = 1;
		
		for (int indexOfNum = 0; indexOfNum < listOfNumbers.length; indexOfNum++) {
			listOfNumbers[indexOfNum] = numCountUp++;
		}
		
		return listOfNumbers;
	}

	@Override
	public int[] getTargets() {

		return targets;
	}

	@Override
	public RunTime runLinearSearch(int[] listOfNumbers, int target, int numberOfTimes) {
		
		for (int counter = 0; counter < numberOfTimes; counter++) {
			newLinearSearch.search(listOfNumbers, target);
		}
		
		return newLinearSearch;
	}

	@Override
	public RunTime runBinarySearch(int[] listOfNumbers, int target, int numberOfTimes) {
		
		for (int counter = 0; counter < numberOfTimes; counter++) {
			newBinarySearch.search(listOfNumbers, target);
		}
		
		return newBinarySearch;
	}
	
	public void resetNewLinearSearchRunTimes(){
		newLinearSearch.resetRunTimes();
	}
	
	public void resetNewBinarySearchRunTimes(){
		newBinarySearch.resetRunTimes();
	}

	public static void main(String[] args) {
		Driver Driver = new Driver();
		
		//create an array to go through targets
		int [] numbers = Driver.getListOfNumbers();
		int[] targets = Driver.getTargets();
		
//		System.out.println("Before linear: " + Arrays.toString(newLinearSearch.getRunTimes()));
				
		for(int i = 0; i < targets.length; i++) {
			Driver.resetNewLinearSearchRunTimes();
//			System.out.println("Before reset of linear at target:" + targets[i] + " " + Arrays.toString(newLinearSearch.getRunTimes()));
			for (int j = 0; j < 10; j++) {
				Driver.runLinearSearch(numbers, targets[i], j);
			}
//			System.out.println("Before reset of linear at target:" + targets[i] + " " + Arrays.toString(newLinearSearch.getRunTimes()));
			Driver.resetNewLinearSearchRunTimes();
		}
				
		System.out.println("After reset of linear: " + Arrays.toString(newBinarySearch.getRunTimes()));
		
		for(int i = 0; i < targets.length; i++) {
//			Runtime rt = driver.runBinarySearch(numbers, targets[i]);
			Driver.resetNewBinarySearchRunTimes();
			for (int j = 0; j < 10; j++) {
				Driver.runBinarySearch(numbers, targets[i], j);
				// runs the method
			}
//			System.out.println("Before reset of Binary at target: " + targets[i] + " " + Arrays.toString(newBinarySearch.getRunTimes()));
			
			Driver.resetNewBinarySearchRunTimes();

		}
//		System.out.println("After reset of binary: " + Arrays.toString(newBinarySearch.getRunTimes()));
		

	}

}
