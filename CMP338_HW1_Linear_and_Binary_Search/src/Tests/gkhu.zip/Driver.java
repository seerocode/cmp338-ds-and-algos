public class Driver implements DriverInterface {
	
	private static int[] listOfNumbers = new int[10000000];
	private static int[] targets = {500, 10000, 100000, 1000000, 5000000, 7500000, 10000000};
	private static  BinarySearch newBinarySearch = new BinarySearch();
	private static LinearSearch newLinearSearch = new LinearSearch();
	private static RunTime rt = new RunTime();

	
	@Override
	public int[] getListOfNumbers() {
		
		int numCountUp = 1;
		
		for (int indexOfNum = 0; indexOfNum < listOfNumbers.length; indexOfNum++) {
			listOfNumbers[indexOfNum] = numCountUp++;
		}
		
		return listOfNumbers;
	}

	@Override
	public int[] getTargets() {

		return targets;
	}

	@Override
	public RunTime runLinearSearch(int[] listOfNumbers, int target, int numberOfTimes) {
		
		for (int counter = 0; counter < numberOfTimes; counter++) {
			newLinearSearch.search(listOfNumbers, target);
		}
		
		return newLinearSearch;
	}

	@Override
	public RunTime runBinarySearch(int[] listOfNumbers, int target, int numberOfTimes) {
		
		for (int counter = 0; counter < numberOfTimes; counter++) {
			newBinarySearch.search(listOfNumbers, target);
		}
		
		return newBinarySearch;
	}
	
	public void resetNewLinearSearchRunTimes(){
		newLinearSearch.resetRunTimes();
	}
	
	public void resetNewBinarySearchRunTimes(){
		newBinarySearch.resetRunTimes();
	}

	public static void main(String[] args) {
		Driver Driver = new Driver();
		
		//create an array to go through targets
		int [] numbers = Driver.getListOfNumbers();
		int[] targets = Driver.getTargets();
		
		for(int i = 0; i < targets.length; i++) {
			for (int j = 0; j < 10; j++) {
				Driver.runLinearSearch(numbers, targets[i], j);
			}
			Driver.resetNewLinearSearchRunTimes();
		}
				
		for(int i = 0; i < targets.length; i++) {
//			Runtime rt = driver.runBinarySearch(numbers, targets[i]);
			for (int j = 0; j < 10; j++) {
				Driver.runBinarySearch(numbers, targets[i], j);
				// runs the method
			}
			Driver.resetNewBinarySearchRunTimes();

		}
		

	}

}
