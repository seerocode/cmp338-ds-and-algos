import java.util.Arrays;

public class BinarySearch extends RunTime implements SearchInterface {
	
	private long runTime;
	private long startTime;
	private long endTime;

	@Override
	public int search(int[] listOfNumbers, int target) {
		
		this.startTime = System.nanoTime();
		
		// beginning search index
		int lowNum = 0;
		// end search index
		int highNum = listOfNumbers.length - 1;
		
//		while (lowNum < highNum) {
//			int midNum = (lowNum + highNum) / 2;
//			if (listOfNumbers[midNum] == target) {
//				return midNum;
//			}
//			else if (listOfNumbers[midNum] < target) {
//				highNum = midNum - 1;
//			}
//			else {
//				lowNum = midNum + 1;
//			}
//		}
		
		while (highNum >= lowNum) {
			int midNum = (lowNum + highNum) / 2;
			if (listOfNumbers[midNum] == target) {
				return midNum;
			}
			else if (listOfNumbers[midNum] < target) {
				lowNum = midNum + 1;
			}
			else {
				highNum = midNum - 1;
			}
		}
		
		this.endTime = System.nanoTime();
		this.runTime = endTime - startTime;
		super.addRuntime(runTime);
		
		return -1;
	}
	
//public static void main (String[] args) {
//		
//		BinarySearch driver = new BinarySearch();
//		RunTime rt = new RunTime();
//		
//		Driver getNums = new Driver();
//		
//		System.out.println(driver.search(getNums.getListOfNumbers(), 50000));
//		
//		System.out.println(driver.runTime);
//		
//		System.out.println(Arrays.toString(rt.getRunTimes()));
//		
//	}

}
