
//import java.util.Arrays;

public class RunTime implements RuntimeInterface {
	
	private long[] runTimeArray = new long[10];
	private int runTimeCounter = 0;


	// This method is used to retrieve the last runtime. 
	// If no runtime has been added, the method will return a zero.
	@Override
	public long getLastRunTime() {
		// get latest non-zero runtime from the array
		/*
		 * Pseudo code:
		 * 	start checking at last element
		 *	check first if last element is non-zero and return that element
		 *	otherwise, decrement from last index until you find a non-zero value
		 * 	return that value
		 * 	if all values equal to zero, return 0
		 */
										
		// start index at last number, while index greater than zero, go into loop
		for (int runTimeIndex = runTimeArray.length - 1; runTimeIndex > 0; runTimeIndex--) {
			// return last index if not zero
			if (runTimeArray[runTimeIndex] != 0) {
				return runTimeArray[runTimeIndex];
			} 
		}
		return 0;
	}

	// This method returns an array of long values representing the last 10 runtimes. 
	// If less than 10 runtimes are available, the remaining runtimes should be zero. 
	// If more than 10 runtimes have been added, the array should contain the last 10 runtimes.
	@Override
	public long[] getRunTimes() {
		
		return runTimeArray;
	}

	// This method is used to reset all 10 linear search times to zero.
	@Override
	public void resetRunTimes() {
		/*
		 * Pseudo code:
		 * 	for each element in the array, set it to zero
		 */
		
		for (int runTimeIndex = 0; runTimeIndex < runTimeArray.length; runTimeIndex++) {
			runTimeArray[runTimeIndex] = 0;
		}

	}

	// This method is used to add a runtime.
	@Override
	public void addRuntime(long runTime) {		
		
		// have a counter for the num of elements have starting at zero
		// every time you add a runtime, if the counter is less than 10, place runtime
		// at counter and increment
		// when the counter reaches 10, you have your full array
		
		// start counter at zero
		
		if (this.runTimeCounter < 10) {
			runTimeArray[this.runTimeCounter] = runTime;
			this.runTimeCounter++;
		}
		else if (this.runTimeCounter >= 10) {
			for (int runTimeIndex = 0; runTimeIndex < runTimeArray.length - 1; runTimeIndex++) {
				runTimeArray[runTimeIndex] = runTimeArray[runTimeIndex + 1];
			}
				runTimeArray[runTimeArray.length - 1] = runTime;
		}
				
	}

	// This method is used to obtain the average runtime. 
	// The method should average all the non-zero runtimes that are available. 
	// If no runtimes are available, the method returns a zero.
	@Override
	public double getAverageRunTime() {
		
		double countHolder = 0;
		double meanOfRunTimes;
		
		if (this.runTimeCounter <= 10) {
			for (int runTimeIndex = 0; runTimeIndex < this.runTimeCounter; runTimeIndex++) {
				countHolder = countHolder + runTimeArray[runTimeIndex];
			}
		}
		
		if (countHolder == 0) {
			meanOfRunTimes = 0;
		}
		else {
			meanOfRunTimes = countHolder / this.runTimeCounter;
		}
		
		return meanOfRunTimes;
	}
	
//	public static void main (String[] args) {
//		
//		BinarySearch driver = new BinarySearch();
//		RunTime rt = new RunTime();
//		
//		Driver getNums = new Driver();
//				
//		rt.addRuntime(100);
//		rt.addRuntime(900);
//		rt.addRuntime(900);
//		rt.addRuntime(900);
//		rt.addRuntime(900);
//		rt.addRuntime(500);
//		rt.addRuntime(700);
//		rt.addRuntime(900);
//		rt.addRuntime(900);
//		rt.addRuntime(100);
//		rt.addRuntime(900);
//		rt.addRuntime(900);
//		rt.addRuntime(900);
//		rt.addRuntime(900);
//		rt.addRuntime(900);
//		rt.addRuntime(900);
//		rt.addRuntime(900);
//		rt.addRuntime(900);
//						
//		System.out.println(Arrays.toString(rt.getRunTimes()));
//		System.out.println(rt.getAverageRunTime());
//	}

}
