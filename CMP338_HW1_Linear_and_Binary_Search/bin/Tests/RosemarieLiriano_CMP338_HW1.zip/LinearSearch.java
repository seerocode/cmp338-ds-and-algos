
public class LinearSearch extends RunTime implements SearchInterface {
	
	private long runTime;
	private long startTime;
	private long endTime;

	// This method is used for searching for a target value in an array representing a listOfNumbers.
	@Override
	public int search(int[] listOfNumbers, int target) {
		/*
		 * Pseudo code: Linear search is searching one by one for a number starting at the beginning
		 * 
		 * for each number in the array,
		 * check if it is equal to the target number,
		 * If not, equal before the end of the array, continue to the next index
		 * If reach end of array, return -1
		 * 
		 */
		
		this.startTime = System.nanoTime();
		
		for (int findNum = 0; findNum < listOfNumbers.length; findNum++) {
			if (listOfNumbers[findNum] == target) {
				return findNum;
			} 
		}
		
		this.endTime = System.nanoTime();
		this.runTime = endTime - startTime;
		super.addRuntime(runTime);
		
		return -1;
	}

}
