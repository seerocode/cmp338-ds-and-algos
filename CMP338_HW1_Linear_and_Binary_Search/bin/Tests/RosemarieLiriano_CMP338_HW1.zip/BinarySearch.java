
public class BinarySearch extends RunTime implements SearchInterface {
	
	private long runTime;
	private long startTime;
	private long endTime;

	@Override
	public int search(int[] listOfNumbers, int target) {
		
		this.startTime = System.nanoTime();
		
		// beginning search index
		int lowNum = 0;
		// end search index
		int highNum = listOfNumbers.length - 1;
		
		while (lowNum < highNum) {
			int midNum = (lowNum + highNum) / 2;
			if (listOfNumbers[midNum] == target) {
				return midNum;
			}
			else if (listOfNumbers[midNum] < target) {
				highNum = midNum - 1;
			}
			else {
				lowNum = midNum + 1;
			}
		}
		
		this.endTime = System.nanoTime();
		this.runTime = endTime - startTime;
		super.addRuntime(runTime);
		
		// return if not found
		return -1;
	}

}
