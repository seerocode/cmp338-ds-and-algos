import java.util.Arrays;

public class Driver implements DriverInterface {


//	Integer[] array;
	
	@Override
	public Integer[] createArray(ArrayType arrayType, int arraySize) {
		
		switch (arrayType) {
			case Equal:
				Integer[] equalArray = new Integer[arraySize];
				for (int value = 0; value < equalArray.length; value++) {
					equalArray[value] = 1;
				}
				return equalArray;
			case Random:
				Integer[] randArray = new Integer[arraySize];
				for (int value = 0; value < randArray.length; value++) {
					randArray[value] = (int)(Math.random() * 100000);
				}
				return randArray;
			case Increasing:
				Integer[] incArray = new Integer[arraySize];
				for (int i = 0; i < incArray.length; i++) {
					incArray[i] = i + 1;
				}
				return incArray;
			case Decreasing:
				Integer[] decArray = new Integer[arraySize];
				int counter = arraySize;
				for (int i = 0; i < decArray.length ; i++) {
					// assign and then decrement
					decArray[i] = counter--;
				}
				return decArray;
			case IncreasingAndRandom:
				// 90% increasing and 10% random
				// 90% of 1000 = 100 random numbers
				// 90% of 10,000 =  1000 random numbers
				Integer[] incAndRandArray = new Integer[arraySize];
				incAndRandArray[0] = 1;
				// - 1 so it doesnt go up to 901
				int arrayAt90Percent = (int) (incAndRandArray.length * .90);
				for (int i = 1; i < arrayAt90Percent; i++) {
					incAndRandArray[i] = i + 1;
				}
				for (int i = arrayAt90Percent; i < incAndRandArray.length ; i++) {
					incAndRandArray[i] = (int)(Math.random() * 100000);
				}
				return incAndRandArray;
		}
		
		return null;
	}

	@Override
	public RunTime runSort(SortType sortType, ArrayType arrayType, int arraySize, int numberOfTimes) {
		
//		for (int counter = 0; counter < numberOfTimes; counter++) {
			switch (sortType) {
				case BubbleSort:
					BubbleSort bubble = new BubbleSort();
					Integer[] bubbleArray = createArray(arrayType, arraySize);
					for (int counter = 0; counter < numberOfTimes; counter++) {
						bubble.sort(bubbleArray);
					}
		
					return bubble;
				case InsertionSort:
					InsertionSort insertion = new InsertionSort();
					Integer[] insertionArray = createArray(arrayType, arraySize);
					for (int counter = 0; counter < numberOfTimes; counter++) {
						insertion.sort(insertionArray);
					}
					
					return insertion;
				case SelectionSort:
					SelectionSort selection = new SelectionSort();
					Integer[] selectionArray = createArray(arrayType, arraySize);
					for (int counter = 0; counter < numberOfTimes; counter++) {
						selection.sort(selectionArray);
					}
					
					return selection;
			} // end switch
//		} // end for loop
		
		return null;
	}
	

	public static void main(String[] args) {
		
		Driver testDrive = new Driver();
//		int timesToRun = 10;
		
		//////// Bubble sorts ////////
		
//		for (int i = 0; i < timesToRun; i++) {
//			testDrive.runSort(SortType.BubbleSort, ArrayType.Equal, 1000, timesToRun);
//		}
		
		// 1,000 Integers
		/// 1. equal 
		testDrive.runSort(SortType.BubbleSort, ArrayType.Equal, 1000, 10);
		/// 2. random
		testDrive.runSort(SortType.BubbleSort, ArrayType.Random, 1000, 10);	
		/// 3. increasing 
		testDrive.runSort(SortType.BubbleSort, ArrayType.Increasing, 1000, 10);	
		/// 4. decreasing
		testDrive.runSort(SortType.BubbleSort, ArrayType.Decreasing, 1000, 10);	
		/// 5. increasing and random
		testDrive.runSort(SortType.BubbleSort, ArrayType.Random, 1000, 10);	
		
		// 10,000 Integers
		/// 1. equal 
		testDrive.runSort(SortType.BubbleSort, ArrayType.Equal, 10000, 10);
		/// 2. random
		testDrive.runSort(SortType.BubbleSort, ArrayType.Random, 10000, 10);	
		/// 3. increasing 
		testDrive.runSort(SortType.BubbleSort, ArrayType.Increasing, 10000, 10);	
		/// 4. decreasing
		testDrive.runSort(SortType.BubbleSort, ArrayType.Decreasing, 10000, 10);	
		/// 5. increasing and random
		testDrive.runSort(SortType.BubbleSort, ArrayType.Random, 10000, 10);	
		
//		System.out.println(Arrays.toString(testDrive.createArray(ArrayType.IncreasingAndRandom, 1000)));
		
//		Your main() method will have to call the runSort() method to sort each of the following array types ten times for each sort algorithm:
//
//			1,000 equal Integers.
//			1,000 random Integers.
//			1,000 increasing Integers.
//			1,000 decreasing Integers.
//			1,000 increasing and random Integers.
//			10,000 equal Integers.
//			10,000 random Integers.
//			10,000 increasing Integers.
//			10,000 decreasing Integers.
//			10,000 increasing and random Integers.
//			For each call to the runSort() method to sort an ArrayType using a SortType ten times, your main() method will produce the following output:
//
//			SortType, ArrayType, Array Size
//			--------------------------------------------------------------------------------------------------------------
//			runTime1 runTime2 runTime3 runTime4 runTime5 runTime6 runTime7 runTime8 runTime9 runTime10 --- Average runTime  

	}

}
