import java.util.Vector;

public class Driver implements DriverInterface {

	@Override
	public Vector<TreeItem<Integer, String>> getVectorOfTreeItems() {
		Vector<TreeItem<Integer, String>> vec = new Vector<TreeItem<Integer, String>>();
		
		int countOfItems = 131071;
		
		for (int i = 0; i < countOfItems; i++){

			int itemKeyInt = (int) ((int) i + 10 * (Math.round(Math.random() * 1000)));

			String itemString = "String " + itemKeyInt;

			TreeItem<Integer, String> item = new TreeItem<Integer, String>(itemKeyInt, itemString);

			vec.add(item);

		}

		return vec;
	}

	@Override
	public BinarySearchTree<Integer, String> createAndPopulateBST(Vector<TreeItem<Integer, String>> treeItems) {

		BinarySearchTree<Integer, String> binarySearchTree = new BinarySearchTree<Integer, String>();

		for (TreeItem<Integer, String> item : treeItems) {
			binarySearchTree.insert(item);
		}

		return binarySearchTree;
	}

}
