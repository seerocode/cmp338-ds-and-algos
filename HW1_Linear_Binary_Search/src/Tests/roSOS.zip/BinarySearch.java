import java.util.Arrays;

public class BinarySearch extends RunTime implements SearchInterface {
	
	private long startTime;
	private long endTime;
	protected long runTime;

	@Override
	public int search(int[] listOfNumbers, int target) {
		
		// start time for loop execution
		this.startTime = System.nanoTime();
		
		// beginning search index
		int lowNum = 0;
		// end search index
		int highNum = listOfNumbers.length - 1;
				
		int foundIndex = -1;

			while (highNum >= lowNum) {
				int midNum = (lowNum + highNum) / 2;
				if (listOfNumbers[midNum] == target) {
//					return midNum;
					foundIndex = midNum;
					break;
				}
				else if (listOfNumbers[midNum] < target) {
					lowNum = midNum + 1;
				}
				else {
					highNum = midNum - 1;
				}
			}
		
			// endtime for loop execution
			this.endTime = System.nanoTime();
			// grab end run time for loop execution
			this.runTime = endTime - startTime;
			// add runtime to runtime method in RunTime class
			this.addRuntime(runTime);	
			
		return foundIndex;
	}
	
	// main method is just for testing
public static void main (String[] args) {
		
		BinarySearch driver = new BinarySearch();
		RunTime rt = new RunTime();
		
		Driver getNums = new Driver();
		
		System.out.println("Index at " + driver.search(getNums.getListOfNumbers(), 10));
		
		System.out.println("Runtime = " + driver.runTime);
//		System.out.println(rt.runTime);
//		rt.addRuntime(driver.runTime);
//		rt.addRuntime(driver.runTime);
		System.out.println(Arrays.toString(rt.getRunTimes()));
		
	}

}
