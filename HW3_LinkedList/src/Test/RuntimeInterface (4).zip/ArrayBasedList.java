
public class ArrayBasedList<I> implements ListInterface<I> {

	private final int NUMBER_OF_ENTRIES = 100;
	private int numObjects; // number of Objects in the list
	private I[] arrayObjects; // an array of objects

	@SuppressWarnings("unchecked")
	public ArrayBasedList() {
		arrayObjects = (I[]) new Object[NUMBER_OF_ENTRIES];
		numObjects = 0;
	}

	// This method is called to obtain the count of elements in the list.
	@Override
	public int size() {
		// Returns the numbers of Objects that are currently in the list.
		return numObjects;
	}

	// This method is called to determine if the list is empty.
	@Override
	public boolean isEmpty() {
		// Returns true if the list is empty, otherwise it returns false.
		return (this.numObjects == 0);
	}

	// This method is called to add the specified object to the end of the list.
	@Override
	public void add(I obj) {

		if (this.isEmpty()) {
			arrayObjects[0] = obj; // set the first element as obj
		} else {
			arrayObjects[this.numObjects++] = obj; // move location up
		}
		; // increase the count of objects
	}

	// This method is called to add the specified object to the list at the given
	// index.
	@Override
	public boolean add(I obj, int index) {

		boolean didSucceed = false;

		// if the index is valid (greater than or equal to 0) and less than the max size
		if (index >= 0 && index <= this.numObjects) {
			
			for (int i = this.numObjects; i >= index; i--) {
				arrayObjects[i+1] = arrayObjects[i];
			}
			arrayObjects[index] = obj;
			numObjects++;
			didSucceed = true;
		}
		return didSucceed;
	}

	// This method is called to add the specified object to the list in sorted
	// order.
	@Override
	public boolean addSorted(I obj) {

		// More specifically, the objects preceding the specified object must be "less
		// than" the specified object, and the objects following the specified object
		// must be "greater that or equal to" the specified object.

		return false;
	}

	// This method is called to retrieve the object at the specified index.
	@Override
	public I get(int index) {

		I getObj = null;

		if (index >= 0 && index < numObjects) {
			getObj = arrayObjects[index];
		}

		return getObj;
	}

	// This method is called to replace the element at the specified index with the
	// specified obj. The method then returns the replaced element or null if no
	// element exists at the specified index.
	@Override
	public I replace(I obj, int index) {
		
		I getObj = null;

		if (index >= 0 && index < NUMBER_OF_ENTRIES) {
			arrayObjects[index] = obj;
			getObj = obj;
		}

		return getObj;
	}

	
	// This method is called to remove the object at the specified index
	@Override
	public boolean remove(int index) {
		boolean removed = false;

		
		if (index >= 0 && index < NUMBER_OF_ENTRIES) {
			arrayObjects[index] = null;
			removed = true;
		}

		return removed;
	}

	// This method removes all objects from the list, making the list empty.
	@Override
	public void removeAll() {
		
//		for (I obj : arrayObjects) {
//			arrayObjects[(int) obj] = null;
//
//		}
	}

//	@Override
//	public int compareTo(Object compObj) {
//		
//		if (compObj == st.age)  
//			return 0;  
//			else if(age>st.age)  
//			return 1;  
//			else  
//			return -1;  
//			}
//
//	return 0;


// public static void main(String[] args) {
// // TODO Auto-generated method stub
//
// }

}

