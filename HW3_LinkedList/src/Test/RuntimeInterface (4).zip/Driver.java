
public class Driver implements DriverInterface {

	@Override
	public ListInterface<Integer> createList(ListType listType, TestType forTestType) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ListInterface<Integer> initializeList(ListInterface<Integer> list, int firstNumber, int lastNumber,
			int increment) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double memoryUsage() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public RunTime runTestCase(ListType listType, TestType testType, int numberOfTimes) {
		// TODO Auto-generated method stub
		return null;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
