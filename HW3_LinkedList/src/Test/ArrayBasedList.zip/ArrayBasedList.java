
public class ArrayBasedList<I> implements ListInterface<I> {
	
	private int size = 0;
	private LinkedListNode<I> head = null;
	private LinkedListNode<I> tail = null;

	// This method is called to obtain the count of elements in the list.
	@Override
	public int size() {
		// Returns the numbers of Objects that are currently in the list.
		return this.size;
	}

	// This method is called to determine if the list is empty.
	@Override
	public boolean isEmpty() {
		// Returns true if the list is empty, otherwise it returns false.
		return (this.size == 0) ? true : false;
	}

	// This method is called to add the specified object to the end of the list.
	@Override
	public void add(I obj) {
		LinkedListNode<I> newNode = new LinkedListNode<I>(obj);
		
//		if (this.isEmpty()) {
//			this.head = newNode;
//			this.tail = newNode;
//		} else {
//			tail.setNext(newNode);
//			tail = newNode;
//		}
//		
//		size++;		
//	}

	@Override
	public boolean add(I obj, int index) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean addSorted(I obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public I get(int index) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public I replace(I obj, int index) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean remove(int index) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void removeAll() {
		// TODO Auto-generated method stub
		
	}

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	}

}
