
public class LinkedList<I> implements ListInterface<I>, Comparable {
	
	private int size = 0;
	private LinkedListNode<I> head = null;
	private LinkedListNode<I> tail = null;

	// This method is called to obtain the count of elements in the list.
	@Override
	public int size() {
		// Returns the numbers of Objects that are currently in the list.
		return this.size;
	}

	// This method is called to determine if the list is empty.
	@Override
	public boolean isEmpty() {
		// Returns true if the list is empty, otherwise it returns false.
		return (this.size == 0) ? true : false;
	}

	// This method is called to add the specified object to the end of the list.
	@Override
	public void add(I obj) {
		LinkedListNode<I> newNode = new LinkedListNode<I>(obj);
		
		if (this.isEmpty()) {
			this.head = newNode;
			this.tail = newNode;
		} else {
			tail.setNext(newNode);
			tail = newNode;
		}
		
		this.size++;		
	}

	// This method is called to add the specified object to the list at the given index.
	@Override
	public boolean add(I obj, int index) {
		
		boolean didSucceed = false;
		
		if(index >= 0 && index < this.size) {
			didSucceed = true;
			
		}
		return didSucceed;
	}

	@Override
	public boolean addSorted(I obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public I get(int index) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public I replace(I obj, int index) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean remove(int index) {
		boolean removed = false;
		
		if ((index >= 0) && (index < this.size)) {
			if (index == 0) {
				// removing the head
				head = head.getNext();
			} else {
				LinkedListNode<I> prevNode = null;
				LinkedListNode<I> curNode = head;
				
				for (int i = 0 ; i < index ; i++ ) {
					prevNode = curNode;
					curNode = curNode.getNext();
				}
				
				prevNode.setNext(curNode.getNext());
				
				if (curNode == tail) {
					tail = prevNode;
				}
			}
			
			size--;
		} 
		
		return removed;
	}

	@Override
	public void removeAll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int compareTo(Object arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	}

}
